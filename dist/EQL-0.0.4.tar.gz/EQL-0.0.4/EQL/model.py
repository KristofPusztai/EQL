import numpy as np

def test():
    return np.sin(np.array([0]))