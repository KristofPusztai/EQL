# Introduction:

A tensorflow implementation of the Equation Learner Neural Network based model:
![Imgur](https://i.imgur.com/HZXwfVI.png)
- https://arxiv.org/pdf/1610.02995.pdf

# Functionality:
